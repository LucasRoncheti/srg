<?php

     include '../../generalPhp/conection.php';
     
     if(!isset($_SESSION)) {
        session_start();
    }
    
    if(!isset($_SESSION['id'])) {
       die( header("Location: ../../index.php"));
       
    }
    
     if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $valorUsuario = $_POST["valor"];
        $produto = $_POST["produto"];
    
        // Remova todos os pontos de milhares e substitua a vírgula pelo ponto (formato decimal correto)
        $valor = str_replace(',', '.', str_replace('.', '', $valorUsuario));
    
        $sql = "INSERT INTO produtos (valor, produto) VALUES ('$valor', '$produto')";
    
        if ($conn->query($sql) === TRUE) {
            echo "Produto cadastrado com sucesso!";
        } else {
            echo "Erro no cadastro: " . $conn->error;
        }
    
        $conn->close();
    }
    
?>
