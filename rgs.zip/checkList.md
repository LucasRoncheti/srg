
[XXX]BUGS[XXX]

[x]validação de senha dos usuários
[x]bug quando deleta o nome todo na pesquisa do produto e cliente na hora de fazer o pedido
[x]colocando letras no input de numero fornecedores
[x]acertar inputs nos pedidos
[x]alterar tamanho da div ou o display do onload
[x]opção de mostrar as infos dos pedidos só com um click style="display: none;"
[x]alterar texto INSPEÇÃO em todos os campos
[?]VALOR DO PRODUTO SEM VIRGULA E PONTO NO INPUT
[x]botão de voltar na hora que está fazendo o pedido mostrar mensagem
[x]bug botão salvar pedido quando não tem nenhuma opção selecionada nos campos
[x]LIMPEZA DE ARQUIVOS DESNECESSÁRIOS
[x]limpar campos de cadastro após ser salvo no BD 
[x] limpar todos os campos após o botão submit 
[x] bug quando abre o pedido no packlist sem ter nada salvo 
[x] limpar os console.log 
[x] menu mobile primeira camada
[x] conferir favicon de todas as páginas 
[x] conferir botão apagar e editar nas buscas 
[x]BOTÃO SALVAR NA HORA DE EDITAR OS PEDIDOS 
[] todas as palavras em uppercase 




[XXX]IMPLEMENTAÇÕES[XXX]
[x]área de login 
[x]estilizar "NÃO É POSSÍVEL LOGAR "
[x]session 
[] erro log

[]área de report  erro
[]animação de loading em todas as requisições com o servidor
[]impressão de páginas
[]converter strings de nomes em maiúsculas 
