
// esse script faz com que  a página atual  volte para a anterior 

backPage =  () =>{
    window.history.back()
}