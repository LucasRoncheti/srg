

function deleteDiv(){
    document.getElementById("pedidoCadastrado").remove()
}