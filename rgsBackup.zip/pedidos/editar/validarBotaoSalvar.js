// divPai = document.getElementById("containerList");

// botaoSalvar = document.getElementById("salvarPedido");

// function contagemDiv() {
//     var elementos = divPai.querySelectorAll(".containerList");
//     if (elementos.length === 0) {
//         botaoSalvar.style.display = 'flex';
//     } else {
//         botaoSalvar.style.display = 'flex';
//     }
// }

// // Crie um MutationObserver para observar as alterações na divPai
// var observer = new MutationObserver(contagemDiv);

// // Configure as opções de observação para verificar mudanças na subárvore
// var config = { childList: true, subtree: true };

// // Inicie a observação na divPai
// observer.observe(divPai, config);

// // Chame a função inicialmente para contar os elementos
// contagemDiv();
